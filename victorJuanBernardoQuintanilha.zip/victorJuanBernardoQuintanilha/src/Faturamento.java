import java.util.ArrayList;

/**
 * 
 * @author 1829203
 *
 */
public class Faturamento {

	public static Double faturamentoEmpresa(ArrayList<NotaFiscal> notas) {
		Double faturamentoTotal = 0d;
		for (NotaFiscal nota : notas) {
			faturamentoTotal += nota.getValor();
		}
		return faturamentoTotal;
	}
	
}